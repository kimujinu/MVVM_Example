package com.example.mvvm_sample

data class ProfileData(var name : String, var age : Int)