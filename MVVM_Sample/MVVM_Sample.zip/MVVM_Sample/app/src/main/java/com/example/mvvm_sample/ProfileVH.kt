package com.example.mvvm_sample

class ProfileVH {
}